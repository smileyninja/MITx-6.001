# MITx-6.00.1x-Introduction-to-Computer-Science-and-Programming-Using-Python
MITx: 6.00.1x Introduction to Computer Science and Programming Using Python
