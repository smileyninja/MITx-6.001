﻿L9 PROBLEM 5  (10/10 points)
For each of the following expressions,
select the order of growth class that best describes it from the following list:
O(1),O(log(n)),O(n),O(nlog(n)),O(nc) or O(cn).

5n
O(n) - correct

3n2+2n−100 
O(n^c) - correct

10log(n)+5n
O(n) - correct

10log(n)+5n2
O(n^c) - correct

3n3−2000n2 
O(n^c) - correct

2n2 
O(n^c) - correct

50n+nlog(n) 
O(n log(n)) - correct

1000+2000000 
O(1) - correct

2n+n2 
O(c^n) - correct

logn+1000 
O(log(n)) - correct
