def square(x):
    '''
    x: int or float.
    '''
    return x**2
