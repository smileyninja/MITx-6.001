def isVowel2(char):
    '''
    char: a single letter of any case

    returns: True if char is a vowel and False otherwise.
    '''
    vowels = ('A','E','I','O','U','a','e','i','o','u')
    
    return char in vowels
