def fourthPower(x):
    '''
    x: int or float.
    '''
    return square(square(x))
