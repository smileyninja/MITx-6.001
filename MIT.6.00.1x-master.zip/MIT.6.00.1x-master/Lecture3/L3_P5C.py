total = 0
for num in range(1, end + 1):
    total += num
print total
