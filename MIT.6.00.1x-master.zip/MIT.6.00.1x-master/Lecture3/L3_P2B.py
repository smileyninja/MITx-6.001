num = 10
print 'Hello!'
while num >= 2:
    print num
    num -= 2
