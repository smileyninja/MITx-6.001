num = 0
while num == 0 or num <= 9:
        num += 2
        print num
print 'Goodbye!' 
    
