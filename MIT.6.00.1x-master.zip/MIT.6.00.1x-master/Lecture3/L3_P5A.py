for num in range(2, 12, 2):
    print num
print 'Goodbye!'
