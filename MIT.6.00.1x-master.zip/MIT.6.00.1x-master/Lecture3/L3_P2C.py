num = 0
count = 0
while end > 0: 
    count += 1
    end -= 1
    num += count
print num
